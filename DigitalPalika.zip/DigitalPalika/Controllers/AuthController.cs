using DigitalPalika.Data;
using Microsoft.AspNetCore.Mvc;
public class AuthController : Controller{

    private DpContext db;
    private readonly IWebHostEnvironment _hostingEnvironment;

public AuthController(DpContext db, IWebHostEnvironment hostingEnvironment)
{
    this.db = db;
    _hostingEnvironment = hostingEnvironment;
}

    public IActionResult Login(){
        return View();
    }

    [HttpPost]

    public IActionResult Login(User user){
        var email = user.Email;
        var password = user.Password;
        var authenticated_user = db.Users?.FirstOrDefault(user=>user.Email==email && user.Password==password);
        if(authenticated_user!=null){
        HttpContext.Session.SetInt32("Id", authenticated_user.Id);
        HttpContext.Session.SetString("FirstNameEn", authenticated_user.FirstNameEn);
        HttpContext.Session.SetString("LastNameEn", authenticated_user.LastNameEn);
        HttpContext.Session.SetString("Email", authenticated_user.Email);
        HttpContext.Session.SetString("IsAdmin",authenticated_user.IsAdmin.ToString());
        TempData["AlertMessage"] = $"{authenticated_user.FirstNameEn} {authenticated_user.LastNameEn} Logged in successfully.";
        TempData["AlertMessageType"] = "success"; 
        return RedirectToAction(nameof(Index),"Home");           
        }
        TempData["AlertMessage"] = "Your email or password is incorrect.";
        TempData["AlertMessageType"] = "danger";
        return View();
    }

    public IActionResult Profile(int Id){
            var user = db.Users?.FirstOrDefault(user => user.Id == Id);
            var llevel = LocalLevel.getLocalLevels();
            ViewBag.User = user;
            ViewBag.llevel = llevel;
            return View(user);
    }
    public IActionResult Logout(){
        if(HttpContext.Session.GetString("Id")!=null){
        TempData["AlertMessage"] = $"{HttpContext.Session.GetString("FirstNameEn")} {HttpContext.Session.GetString("LastNameEn")} Logged out successfully.";
        TempData["AlertMessageType"] = "success";
        HttpContext.Session.Clear();
        }
    TempData["AlertMessage"] = "Logout Sucessfully. Login here.";
    TempData["AlertMessageType"] = "primary"; 
      return RedirectToAction("Login","Auth");  
    }
    public IActionResult Signup(){
        var llevel = LocalLevel.getLocalLevels();
        ViewBag.llevel = llevel;
        return View();
    }

    [HttpPost]
    public IActionResult Signup(User user, IFormFile photo){
    if (photo != null && photo.Length > 0)
    {
        var uploadsFolder = Path.Combine(_hostingEnvironment.WebRootPath, "uploads");
        var uniqueFileName = Guid.NewGuid().ToString() + "_" + photo.FileName;
        var filePath = Path.Combine(uploadsFolder, uniqueFileName);
        photo.CopyTo(new FileStream(filePath, FileMode.Create));
        user.Photo = uniqueFileName;
    }
    if(Request.Form["ConfirmPassword"]!=user.Password){
    TempData["AlertMessage"] = "Password Milena.";
    TempData["AlertMessageType"] = "danger";  
    return RedirectToAction(nameof(Index),"Home");    
    }
    db.Users?.Add(user);
    db.SaveChanges();
    TempData["AlertMessage"] = "Form Submited successfully. Login to continue...";
    TempData["AlertMessageType"] = "success";
    return RedirectToAction(nameof(Login),"Auth");
    }
}