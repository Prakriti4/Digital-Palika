using Microsoft.AspNetCore.Mvc;

public class ErrorController : Controller{
    public IActionResult Error404(){
        return View();
    }
}