using DigitalPalika.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

public class ProfileController : Controller
{
    private DpContext db;

    public ProfileController(DpContext db)
    {
        this.db = db;
    }

    public string ToNepaliNumber(string englishNumber)
    {
        string nepaliNumber = "";
        char ch;
        for (int i = 0; i < englishNumber.Length; i++)
        {
            ch = englishNumber[i];
            Console.WriteLine(ch);
            switch (ch)
            {
                case '1':
                    nepaliNumber += '१';
                    break;
                case '2':
                    nepaliNumber += '२';
                    break;
                case '3':
                    nepaliNumber += '३';
                    break;
                case '4':
                    nepaliNumber += '४';
                    break;
                case '5':
                    nepaliNumber += '५';
                    break;
                case '6':
                    nepaliNumber += '६';
                    break;
                case '7':
                    nepaliNumber += '७';
                    break;
                case '8':
                    nepaliNumber += '८';
                    break;
                case '9':
                    nepaliNumber += '९';
                    break;
                default:
                    nepaliNumber += ch;
                    break;
            }
        }
        return nepaliNumber;
    }
    public IActionResult Index(int Id)
    {
        if (HttpContext.Session.GetInt32("Id") == Id)
        {
            var user = db.Users?.FirstOrDefault(user => user.Id == Id);
            if (user == null)
            {
                return NotFound();
            }
            var llevel = LocalLevel.getLocalLevels();
            ViewBag.User = user;
            ViewBag.llevel = llevel;
            return View(user);
        }
        TempData["AlertMessage"] = $"You are not allowed for this action. ";
        TempData["AlertMessageType"] = "danger";
        return RedirectToAction(nameof(Index), "Home");
    }

    public IActionResult Print(int Id)
    {
        if (HttpContext.Session.GetInt32("Id") == Id)
        {
            var user = db.Users?.FirstOrDefault(user => user.Id == Id);
            ViewBag.WardNo = ToNepaliNumber(user?.WardNo.ToString());
            return View(user);
        }
        TempData["AlertMessage"] = $"You are not allowed for this action. ";
        TempData["AlertMessageType"] = "danger";
        return RedirectToAction(nameof(Index), "Home");
    }

    public IActionResult Delete(int Id)
    {
        if (HttpContext.Session.GetInt32("Id") == Id)
        {
            var user = db.Users?.FirstOrDefault(user => user.Id == Id);
            if (user != null)
            {
                db.Users?.Remove(user);
                db.SaveChanges();
                TempData["AlertMessage"] = $"{user.FirstNameEn} {user.LastNameEn} Deleted Successfully.";
                TempData["AlertMessageType"] = "warning";
                HttpContext.Session.Clear();
            }
            return RedirectToAction(nameof(Index), "Home");
        }

        TempData["AlertMessage"] = $"You are not allowed for this action. ";
        TempData["AlertMessageType"] = "danger";
        return RedirectToAction(nameof(Index), "Home");
    }

    public IActionResult Update(User user)
    {
        if (HttpContext.Session.GetInt32("Id") == user.Id)
        {
            db.Users.Attach(user);
            db.Entry(user).State = EntityState.Modified;
            db.SaveChanges();
            TempData["AlertMessage"] = $"Your form updated successfully. ";
            TempData["AlertMessageType"] = "success";
        }

        TempData["AlertMessage"] = $"You are not allowed for this action. ";
        TempData["AlertMessageType"] = "danger";
        return RedirectToAction(nameof(Index), "Home");
    }
}