using Microsoft.AspNetCore.Mvc;
using DigitalPalika.Data;
using System.Text.Json;

public class AdminController : Controller
{

    private DpContext db;

    public object Context { get; private set; }

    public string ToNepaliNumber(string englishNumber)
    {
        string nepaliNumber = "";
        char ch;
        for (int i = 0; i < englishNumber.Length; i++)
        {
            ch = englishNumber[i];
            Console.WriteLine(ch);
            switch (ch)
            {
                case '1':
                    nepaliNumber += '१';
                    break;
                case '2':
                    nepaliNumber += '२';
                    break;
                case '3':
                    nepaliNumber += '३';
                    break;
                case '4':
                    nepaliNumber += '४';
                    break;
                case '5':
                    nepaliNumber += '५';
                    break;
                case '6':
                    nepaliNumber += '६';
                    break;
                case '7':
                    nepaliNumber += '७';
                    break;
                case '8':
                    nepaliNumber += '८';
                    break;
                case '9':
                    nepaliNumber += '९';
                    break;
                default:
                    nepaliNumber += ch;
                    break;
            }
        }
        return nepaliNumber;
    }
    public AdminController(DpContext db)
    {
        this.db = db;
    }
    public IActionResult Index()
    {

        if (HttpContext.Session.GetString("IsAdmin") == "True")
        {
            var users = db.Users?.Where(user => user.IsAdmin == false).ToList();
            return View(users);
        }
        TempData["AlertMessage"] = $"You must login as admin for this process.";
        TempData["AlertMessageType"] = "primary";
        return RedirectToAction("Login", "Auth");
    }
    public IActionResult View(int Id)
    {
        if (HttpContext.Session.GetString("IsAdmin") == "True")
        {
            var user = db.Users?.FirstOrDefault(user => user.Id == Id);
            var llevel = LocalLevel.getLocalLevels();
            ViewBag.User = user;
            ViewBag.llevel = llevel;
            return View(user);
        }
        TempData["AlertMessage"] = $"You must login as admin for this process.";
        TempData["AlertMessageType"] = "primary";
        return RedirectToAction("Login", "Auth");
    }
    public IActionResult Edit(int Id)
    {
        if (HttpContext.Session.GetString("IsAdmin") == "True")
        {
            var user = db.Users?.FirstOrDefault(user => user.Id == Id);
            var llevel = LocalLevel.getLocalLevels();
            ViewBag.User = user;
            ViewBag.llevel = llevel;
            return View(user);
        }
        TempData["AlertMessage"] = $"You must login as admin for this process.";
        TempData["AlertMessageType"] = "primary";
        return RedirectToAction("Login", "Auth");
    }

    public IActionResult Print(int Id)
    {
        if (HttpContext.Session.GetString("IsAdmin") == "True")
        {
            var user = db.Users?.FirstOrDefault(user => user.Id == Id);
            ViewBag.WardNo = ToNepaliNumber(user?.WardNo.ToString());
            return View(user);
        }
        TempData["AlertMessage"] = $"You must login as admin for this process.";
        TempData["AlertMessageType"] = "primary";
        return RedirectToAction("Login", "Auth");
    }
    public IActionResult Delete(int Id)
    {
        if (HttpContext.Session.GetString("IsAdmin") == "True")
        {
            var user = db.Users?.FirstOrDefault(user => user.Id == Id);
            if (user != null)
            {
                db.Users?.Remove(user);
                db.SaveChanges();
                TempData["AlertMessage"] = $"{user.FirstNameEn} {user.LastNameEn} Deleted Successfully.";
                TempData["AlertMessageType"] = "warning";
            }
            return RedirectToAction(nameof(Index), "Admin");
        }
        TempData["AlertMessage"] = $"You must login as admin for this process.";
        TempData["AlertMessageType"] = "primary";
        return RedirectToAction("Login", "Auth");

    }

    public IActionResult Accept(int Id){
        if (HttpContext.Session.GetString("IsAdmin") == "True")
        {
            var user = db.Users?.FirstOrDefault(user => user.Id == Id);
            if (user != null)
            {
                user.IsAccepted = !user.IsAccepted;
                db.SaveChanges();
                if(user.IsAccepted==true){
                TempData["AlertMessage"] = $"{user.FirstNameEn} {user.LastNameEn} Accepted Successfully.";
                TempData["AlertMessageType"] = "success";
                }
                else{
                TempData["AlertMessage"] = $"{user.FirstNameEn} {user.LastNameEn} is Rejected.";
                TempData["AlertMessageType"] = "danger";                    
                }
            }
            return RedirectToAction(nameof(Index), "Admin");
        }
        TempData["AlertMessage"] = $"You must login as admin for this process.";
        TempData["AlertMessageType"] = "primary";
        return RedirectToAction("Login", "Auth");
    }
}