using Microsoft.EntityFrameworkCore;


namespace DigitalPalika.Data{
public class DpContext:DbContext{

    public DpContext(){
        
    }
    public DpContext(DbContextOptions<DpContext> options):base(options)
    {
    }

    public DbSet<User>? Users { get; set; }
        
}
}