public class LocalLevel
{
    public string? name;

    static public List<LocalLevel> getLocalLevels()
    {
        var l1 = new LocalLevel() { name = "Budhanilkantha" };
        var l2 = new LocalLevel() { name = "Chandragiri" };
        var l3 = new LocalLevel() { name = "Dakshinkali" };
        var l4 = new LocalLevel() { name = "Gokarneshwor" };
        var l5 = new LocalLevel() { name = "Kageshwori" };
        var l6 = new LocalLevel() { name = "Kathmandu" };
        var l7 = new LocalLevel() { name = "Kirtipur" };
        var l8 = new LocalLevel() { name = "Nagarjun" };
        var l9 = new LocalLevel() { name = "Shankharapur" };
        var l10 = new LocalLevel() { name = "Tarkeshwor" };
        var l11 = new LocalLevel() { name = "Tokha" };
        List<LocalLevel> localLevels = new List<LocalLevel>() { l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11 };
        return localLevels;
    }
}