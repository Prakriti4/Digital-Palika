using System.ComponentModel.DataAnnotations;

public class User
{
    public int Id { get; set; }
    
    [Display(Name ="First Name")]
    public string? FirstNameEn { get; set; } 

    [Display(Name ="Middle Name")]
    public string? MiddleNameEn { get; set; } 

    [Display(Name ="Last Name")]
    public string? LastNameEn { get; set; } 

    [Display(Name ="पहिलो नाम")]
    public string? FirstNameNp { get; set; } 

    [Display(Name ="बिचको नाम")]
    public string? MiddleNameNp { get; set; } 

    [Display(Name ="थर")]
    public string? LastNameNp { get; set; } 
    public string? Email { get; set; } 
    public string? Phone { get; set; } 

    [Display(Name ="आमाको नाम")]
    public string? MotherNameNp { get; set; } 

    [Display(Name ="बुबाको नाम")]
    public string? FatherNameNp { get; set; } 

    [Display(Name ="Date of Birth")]
    [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
    public DateTime DateOfBirth { get; set; }

    [Display(Name ="Gender")]
    public string? Gender { get; set; } 

    [Display(Name ="Choose District")]
    public string? District {get; set;} 

    [Display(Name ="Choose Local Level")]
    public string? LocalLevel {get; set;}

    [Display(Name ="Choose Ward No")]
    public int WardNo {get; set;}

    [Display(Name ="Photo")]
    public string? Photo { get; set; }

    [Display(Name="Password")]
    public string? Password { get; set; }

    public bool? IsAdmin {get; set;}=false;

    public bool? IsAccepted {get; set; }=false;

    public bool? IsCompleted {get; set; }=false;

}