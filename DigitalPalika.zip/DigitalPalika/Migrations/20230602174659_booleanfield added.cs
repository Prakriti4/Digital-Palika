﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DigitalPalika.Migrations
{
    /// <inheritdoc />
    public partial class booleanfieldadded : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsAccepted",
                table: "Users",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsCompleted",
                table: "Users",
                type: "INTEGER",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsAccepted",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "IsCompleted",
                table: "Users");
        }
    }
}
